SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C003/scripts/plugDatabase.log append
spool /opt/oracle/admin/C003/scripts/plugDatabase.log append
CREATE PLUGGABLE DATABASE "PDB1" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  PARALLEL  file_name_convert=NONE  STORAGE INHERIT;
select name from v$containers where upper(name) = 'PDB1';
alter pluggable database "PDB1" open;
alter system register;
ALTER SESSION SET CONTAINER = "PDB1";
select con_id from v$pdbs where con_id > 1 and upper(name)=upper('PDB1') ;
SELECT bigfile FROM sys.cdb_tablespaces WHERE tablespace_name='TEMP' AND CON_ID=0;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP_NON_ENC TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP_NON_ENC";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "PDB1" CLOSE IMMEDIATE;
alter pluggable database "PDB1" open;
alter system register;
ALTER SESSION SET CONTAINER = "PDB1";
drop tablespace TEMP including contents and datafiles;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "PDB1" CLOSE IMMEDIATE;
alter pluggable database "PDB1" open;
alter system register;
ALTER SESSION SET CONTAINER = "PDB1";
drop tablespace TEMP_NON_ENC including contents and datafiles;
