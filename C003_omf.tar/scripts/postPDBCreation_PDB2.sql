SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
alter session set container="PDB2";
set echo on
spool /opt/oracle/admin/C003/scripts/postPDBCreation1R.log append
CREATE BIGFILE TABLESPACE "USERS" LOGGING  DATAFILE  SIZE 7M AUTOEXTEND ON NEXT  1280K MAXSIZE UNLIMITED  EXTENT MANAGEMENT LOCAL  SEGMENT SPACE MANAGEMENT  AUTO;
ALTER DATABASE DEFAULT TABLESPACE "USERS";
host /opt/oracle/product/26ai/dbhome_1/OPatch/datapatch -skip_upgrade_check -db C003 -pdbs PDB2;
connect "SYS"/"&&sysPassword" as SYSDBA
select property_value from database_properties where property_name='LOCAL_UNDO_ENABLED';
connect "SYS"/"&&sysPassword" as SYSDBA
alter session set container="PDB2";
set echo on
spool /opt/oracle/admin/C003/scripts/postPDBCreation1R.log append
connect "SYS"/"&&sysPassword" as SYSDBA
alter session set container="PDB2";
set echo on
spool /opt/oracle/admin/C003/scripts/postPDBCreation1R.log append
select TABLESPACE_NAME from cdb_tablespaces a,dba_pdbs b where a.con_id=b.con_id and UPPER(b.pdb_name)=UPPER('PDB2');
connect "SYS"/"&&sysPassword" as SYSDBA
alter session set container="PDB2";
set echo on
spool /opt/oracle/admin/C003/scripts/postPDBCreation1R.log append
Select count(*) from dba_registry where comp_id = 'DV' and status='VALID';
show con_name;
alter session set container="PDB2";
select count(a.username) from cdb_users a, v$pdbs b where a.con_id=b.con_id and a.username=upper('PDBADMIN') and upper(b.name)=upper('PDB2');
show con_name;
alter session set container="CDB$ROOT";
alter session set container=CDB$ROOT;
exit;
