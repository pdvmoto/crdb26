SET VERIFY OFF
set echo on
spool /opt/oracle/admin/C1/scripts/PDBCreation.log append
