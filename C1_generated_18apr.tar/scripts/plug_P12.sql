SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C1/scripts/plugDatabase1R.log append
spool /opt/oracle/admin/C1/scripts/plugDatabase1R.log append
CREATE PLUGGABLE DATABASE "P12" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  PARALLEL  file_name_convert=NONE  STORAGE INHERIT;
select name from v$containers where upper(name) = 'P12';
alter pluggable database "P12" open;
alter system register;
ALTER SESSION SET CONTAINER = "P12";
select con_id from v$pdbs where con_id > 1 and upper(name)=upper('P12') ;
SELECT bigfile FROM sys.cdb_tablespaces WHERE tablespace_name='TEMP' AND CON_ID=0;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP_NON_ENC TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP_NON_ENC";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "P12" CLOSE IMMEDIATE;
alter pluggable database "P12" open;
alter system register;
ALTER SESSION SET CONTAINER = "P12";
drop tablespace TEMP including contents and datafiles;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "P12" CLOSE IMMEDIATE;
alter pluggable database "P12" open;
alter system register;
ALTER SESSION SET CONTAINER = "P12";
drop tablespace TEMP_NON_ENC including contents and datafiles;
