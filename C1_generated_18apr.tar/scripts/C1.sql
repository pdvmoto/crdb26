set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /opt/oracle/product/26ai/dbhome_1/bin/orapwd file=/opt/oracle/product/26ai/dbhome_1/dbs/orapwC1 force=y format=12
@/opt/oracle/admin/C1/scripts/CreateDB.sql
@/opt/oracle/admin/C1/scripts/CreateDBFiles.sql
@/opt/oracle/admin/C1/scripts/CreateDBCatalog.sql
@/opt/oracle/admin/C1/scripts/JServer.sql
@/opt/oracle/admin/C1/scripts/context.sql
@/opt/oracle/admin/C1/scripts/cwmlite.sql
@/opt/oracle/admin/C1/scripts/spatial.sql
@/opt/oracle/admin/C1/scripts/labelSecurity.sql
@/opt/oracle/admin/C1/scripts/datavault.sql
@/opt/oracle/admin/C1/scripts/CreateClustDBViews.sql
@/opt/oracle/admin/C1/scripts/lockAccount.sql
@/opt/oracle/admin/C1/scripts/postDBCreation.sql
@/opt/oracle/admin/C1/scripts/PDBCreation.sql
@/opt/oracle/admin/C1/scripts/plug_P11.sql
@/opt/oracle/admin/C1/scripts/postPDBCreation_P11.sql
@/opt/oracle/admin/C1/scripts/plug_P12.sql
@/opt/oracle/admin/C1/scripts/postPDBCreation_P12.sql
