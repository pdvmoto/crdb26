SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C1/scripts/labelSecurity.log append
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/C1/scripts  -v   -b  catols  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catols.sql;
spool off
