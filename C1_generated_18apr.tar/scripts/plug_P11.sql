SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C1/scripts/plugDatabase.log append
spool /opt/oracle/admin/C1/scripts/plugDatabase.log append
CREATE PLUGGABLE DATABASE "P11" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  PARALLEL  file_name_convert=NONE  STORAGE INHERIT;
select name from v$containers where upper(name) = 'P11';
alter pluggable database "P11" open;
alter system register;
ALTER SESSION SET CONTAINER = "P11";
select con_id from v$pdbs where con_id > 1 and upper(name)=upper('P11') ;
SELECT bigfile FROM sys.cdb_tablespaces WHERE tablespace_name='TEMP' AND CON_ID=0;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP_NON_ENC TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP_NON_ENC";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "P11" CLOSE IMMEDIATE;
alter pluggable database "P11" open;
alter system register;
ALTER SESSION SET CONTAINER = "P11";
drop tablespace TEMP including contents and datafiles;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP TEMPFILE SIZE 20480K AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "P11" CLOSE IMMEDIATE;
alter pluggable database "P11" open;
alter system register;
ALTER SESSION SET CONTAINER = "P11";
drop tablespace TEMP_NON_ENC including contents and datafiles;
