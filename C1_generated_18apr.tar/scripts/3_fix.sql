

-- 3_crdb : contains the various components and post creation
-- 
-- todo/questions
-- 	- why the ";"  behind the script ? 
--	- put the defines for CATCTL and CATCON in separate file
--	- why so many reconnects ? 
--	- sinds v21, no more .. 
-- 
-- stmnts copied in from :
--	JServer.sql
--	context.sql
--	cwmlite.sql
--	spatial.sql
--	CreateClustDBViews.sql
--	lockAccount.sql
--	postDBCreation.sql
-- 

spool log_3_fix.log append

host echo Start of 3_crdb_comp at `date` 

@accpwds 

-- JServeer...

SET VERIFY OFF

connect "SYS"/"&&sysPassword" as SYSDBA

set echo on

-- start with some Defines to shorten the commands, define RCTL and RCON
-- notice how -l sends lofiles to /tmp
-- notice how catctl does not have a -v

DEFINE CATCTL="$ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catctl.pl -n 4 -l /tmp "
DEFINE CATCON="$ORACLE_HOME/perl/bin/perl $ORACLE_HOME/rdbms/admin/catcon.pl -n 1 -l /tmp -v "

-- first: jserver
-- why do all script re-connect ? 

host &&CATCON -b dbmsxdbt  -c 'PDB$SEED CDB$ROOT' -U  "SYS"/"&&sysPassword"         $ORACLE_HOME/rdbms/admin/dbmsxdbt.sql;


host echo End of 3_crdb_comp at `date` 

spool off

-- notes below

