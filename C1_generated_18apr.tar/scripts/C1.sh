#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /opt/oracle
mkdir -p /opt/oracle/admin/C1/dpdump
mkdir -p /opt/oracle/admin/C1/pfile
mkdir -p /opt/oracle/admin/C1/scripts
mkdir -p /opt/oracle/audit
mkdir -p /opt/oracle/fast_recovery_area
mkdir -p /opt/oracle/oradata
mkdir -p /opt/oracle/product/26ai/dbhome_1/dbs
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=C1; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/perl/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: C1:/opt/oracle/product/26ai/dbhome_1:Y
/opt/oracle/product/26ai/dbhome_1/bin/sqlplus /nolog @/opt/oracle/admin/C1/scripts/C1.sql
