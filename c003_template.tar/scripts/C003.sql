set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /opt/oracle/product/26ai/dbhome_1/bin/orapwd file=/opt/oracle/product/26ai/dbhome_1/dbs/orapwC003 force=y format=12
@/opt/oracle/admin/C003/scripts/CreateDB.sql
@/opt/oracle/admin/C003/scripts/CreateDBFiles.sql
@/opt/oracle/admin/C003/scripts/CreateDBCatalog.sql
@/opt/oracle/admin/C003/scripts/JServer.sql
@/opt/oracle/admin/C003/scripts/context.sql
@/opt/oracle/admin/C003/scripts/cwmlite.sql
@/opt/oracle/admin/C003/scripts/spatial.sql
@/opt/oracle/admin/C003/scripts/CreateClustDBViews.sql
@/opt/oracle/admin/C003/scripts/lockAccount.sql
@/opt/oracle/admin/C003/scripts/postDBCreation.sql
@/opt/oracle/admin/C003/scripts/PDBCreation.sql
@/opt/oracle/admin/C003/scripts/plug_C003pdb1.sql
@/opt/oracle/admin/C003/scripts/postPDBCreation_C003pdb1.sql
@/opt/oracle/admin/C003/scripts/plug_C003pdb2.sql
@/opt/oracle/admin/C003/scripts/postPDBCreation_C003pdb2.sql
