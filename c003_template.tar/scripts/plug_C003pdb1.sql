SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C003/scripts/plugDatabase.log append
spool /opt/oracle/admin/C003/scripts/plugDatabase.log append
host mkdir -p /opt/oracle/oradata/C003/C003pdb1;
select d.name||'|'||t.name from v$datafile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
select d.name||'|'||t.name from v$tempfile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
CREATE PLUGGABLE DATABASE "C003pdb1" ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  PARALLEL  file_name_convert=('/opt/oracle/oradata/C003/pdbseed',
'/opt/oracle/oradata/C003/C003pdb1')  STORAGE INHERIT;
select name from v$containers where upper(name) = 'C003PDB1';
alter pluggable database "C003pdb1" open;
alter system register;
ALTER SESSION SET CONTAINER = "C003pdb1";
select con_id from v$pdbs where con_id > 1 and upper(name)=upper('C003pdb1') ;
SELECT bigfile FROM sys.cdb_tablespaces WHERE tablespace_name='TEMP' AND CON_ID=0;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP_NON_ENC TEMPFILE '/opt/oracle/oradata/C003/C003pdb1/temp01_NON_ENC.dbf' SIZE 20480K REUSE AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP_NON_ENC";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "C003pdb1" CLOSE IMMEDIATE;
alter pluggable database "C003pdb1" open;
alter system register;
ALTER SESSION SET CONTAINER = "C003pdb1";
drop tablespace TEMP including contents and datafiles;
CREATE SMALLFILE TEMPORARY TABLESPACE TEMP TEMPFILE '/opt/oracle/oradata/C003/C003pdb1/temp01.dbf' SIZE 20480K REUSE AUTOEXTEND ON NEXT  64M MAXSIZE UNLIMITED;
ALTER DATABASE DEFAULT TEMPORARY TABLESPACE "TEMP";
alter session set container=cdb$root;
ALTER PLUGGABLE DATABASE "C003pdb1" CLOSE IMMEDIATE;
alter pluggable database "C003pdb1" open;
alter system register;
ALTER SESSION SET CONTAINER = "C003pdb1";
drop tablespace TEMP_NON_ENC including contents and datafiles;
