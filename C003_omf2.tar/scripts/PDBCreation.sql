SET VERIFY OFF
set echo on
spool /opt/oracle/admin/C003/scripts/PDBCreation.log append
