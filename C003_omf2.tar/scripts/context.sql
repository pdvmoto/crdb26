SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /opt/oracle/admin/C003/scripts/context.log append
-- fixed the arguments..
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/C003/scripts  -v   -b  catctx  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/product/26ai/dbhome_1/ctx/admin/catctx.sql 1Xbkfsdcdf1ggh_123 1SYSAUX 1TEMP 1LOCK ;
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/C003/scripts  -v   -b  dr0defin  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  -a 1   /opt/oracle/product/26ai/dbhome_1/ctx/admin/defaults/dr0defin.sql;
host /opt/oracle/product/26ai/dbhome_1/perl/bin/perl  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/catcon.pl  -n  1  -l  /opt/oracle/admin/C003/scripts  -v   -b  dbmsxdbt  -c   'PDB$SEED CDB$ROOT'    -U  "SYS"/"&&sysPassword"  /opt/oracle/product/26ai/dbhome_1/rdbms/admin/dbmsxdbt.sql;
spool off
